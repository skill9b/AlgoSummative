GD1P02 Algorithms and Data Structures
BFS,DFS and A* Pathfinding

BFS,DFS:
- Nodes are defined by numbers (e.g the first node is always "0")
- Nodes start at 0
- Searching also starts at 0 therefore all edges must connect to 0 to be outputted

A* Pathfinding:
- The grid of check boxes on the left set the start and end position
- The grid of check boxes on right is used to input the position of obstacles
- The final button to calculate the path is "Compute A* Path"

Created by: Jay Patel and Vivian Xu